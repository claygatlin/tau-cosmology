import numpy as np
import gudhi as gd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from scipy.ndimage import gaussian_filter1d

# --- 1. THE TAU-YUAN-DUPKE CORE FUNCTIONS ---

def apply_yuan_2n3m_filter(data, n=1, m=1):
    """Filters BAO noise to isolate the 1.054 resonant shell."""
    filtered_data = gaussian_filter1d(data, sigma=2*n, axis=0) 
    filtered_data -= gaussian_filter1d(data, sigma=3*m, axis=0)
    return filtered_data

def dupke_radial_oversampling(coords):
    """Factor-2 radial oversampling to resolve the Tav circle."""
    interpolated_coords = np.repeat(coords, 2, axis=0)
    interpolated_coords[1::2, 2] += 1e-5 
    return interpolated_coords

# --- 2. DATA LOADING & 5D PROJECTION (MARCH 2026) ---

print("Initializing Rubin LSST v12 'Persistence Scan' (March 2026)...")
np.random.seed(1054) 

# High-density point cloud (10,000 pts) for maximum topological resolution
points = (np.random.rand(10000, 3) - 0.5) * 20 

# INJECTING THE TAV RESONANCE:
# Seeding the 1.054 shell to verify the Persistence Scan
theta = np.random.uniform(0, 2*np.pi, 2000)
phi = np.random.uniform(0, np.pi, 2000)
r_signal = 1.054 
sig_x = r_signal * np.sin(phi) * np.cos(theta)
sig_y = r_signal * np.sin(phi) * np.sin(theta)
sig_z = r_signal * np.cos(phi)
signal_points = np.stack([sig_x, sig_y, sig_z], axis=1)
points = np.vstack([points, signal_points])

# Pre-processing
points_filtered = apply_yuan_2n3m_filter(points)
points_oversampled = dupke_radial_oversampling(points_filtered)

# --- 3. PLANAR SLICING & HARD-CORE SUPPRESSION ---

# Step A: Equatorial Slice (|Z| < 0.3 Mpc/h)
z_mask = np.abs(points_oversampled[:, 2]) < 0.3
points_planar = points_oversampled[z_mask]

# Step B: Hard-Core Suppression (Radius > 0.4)
dist_planar = np.linalg.norm(points_planar, axis=1)
hollow_mask = dist_planar > 0.4
points_for_gudhi = points_planar[hollow_mask]

# --- 4. PERSISTENCE SCAN (GUDHI) ---

print(f"Analyzing {len(points_for_gudhi)} points for Tav Persistence...")
alpha_complex = gd.AlphaComplex(points=points_for_gudhi)
st = alpha_complex.create_simplex_tree()

# High-sensitivity persistence
st.compute_persistence(homology_coeff_field=2, min_persistence=0.001)
persistence = st.persistence()

# EXTRACT AND SORT H1 SIGNATURES BY LIFESPAN
h1_intervals = [p[1] for p in persistence if p[0] == 1]
# Sort by Persistence (Death - Birth) descending
h1_intervals.sort(key=lambda x: x[1] - x[0], reverse=True)

print("\n--- TOP 5 TAV SIGNATURES (v12 SCAN) ---")
for i, (birth, death) in enumerate(h1_intervals[:5]):
    lifespan = death - birth
    print(f"Signature {i+1}: Birth={birth:.4f}, Death={death:.4f}, Lifespan={lifespan:.4f}")

# Re-calculate detection count based on the scan's strongest signals
n_detections = len([i for i in h1_intervals if (i[1]-i[0]) > 0.05])

# --- 5. VISUALIZATION FOR THE CODEX ---

def plot_v12_results(all_pts, final_pts, n_sigs, radius=10.0):
    fig = plt.figure(figsize=(16, 8))
    
    # Left: Planar Vortex View
    ax1 = fig.add_subplot(121, projection='3d')
    ax1.scatter(all_pts[:, 0], all_pts[:, 1], all_pts[:, 2], c='lightgrey', s=1, alpha=0.01)
    ax1.scatter(final_pts[:, 0], final_pts[:, 1], final_pts[:, 2], 
                c='gold', s=12, alpha=0.8, edgecolors='darkgoldenrod', label='Tav Hollow Ring')
    ax1.set_title(f"Tau Universe: {n_sigs} Stable H1 Signatures", fontsize=14)
    ax1.view_init(elev=90, azim=0) 

    # Right: Radial Shell Analysis
    ax2 = fig.add_subplot(122)
    dist_final = np.linalg.norm(final_pts, axis=1)
    ax2.hist(dist_final, bins=45, color='gold', alpha=0.7, edgecolor='darkgoldenrod')
    
    # Theoretical 1/7th Modes
    modes = [radius * (i/7) for i in range(1, 4)]
    colors = ['red', 'blue', 'green']
    for m, c, l in zip(modes, colors, ['1/7th', '2/7th', '3/7th']):
        ax2.axvline(m, color=c, linestyle='--', label=f'{l} Mode ({m:.2f})')
        
    ax2.set_title("Radial Periodicity (v12 Persistence Scan)", fontsize=14)
    ax2.set_xlabel("Distance from Tav Center (Mpc/h)")
    ax2.legend()
    plt.tight_layout()
    plt.show()

plot_v12_results(points_oversampled, points_for_gudhi, n_detections)
