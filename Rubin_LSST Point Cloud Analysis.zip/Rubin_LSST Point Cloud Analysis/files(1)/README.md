# Simulated Topological Detection of the 1.054 Berard Constant (v15)

**Author:** Ernest C. Gatlin III
**Status:** Pre-Observation Simulation & Prediction (March 2026)
**License:** [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)

---

## Overview

This repository contains a **synthetic verification** of the Tav Topology
pipeline (v15). The Python code constructs a controlled point cloud with a
planted toroidal shell at radius 1.054 (author-designated "Berard Constant"),
then applies the Tau-Yuan-Dupke filtering pipeline and GUDHI persistent
homology to recover the planted H₁ feature.

**Important methodological note.** The v15 code is a *simulation*, not a blind
detection. The 1.054 shell is injected into the synthetic point cloud before
analysis. The purpose is to demonstrate that the pipeline is mathematically
capable of isolating a loop-like (H₁) topological feature at a specified
scale against a stochastic background—not to claim discovery in observational
data. All terminology introduced here (Berard Constant, Tav Ring,
Tau-Yuan-Dupke Pipeline) is proposed by the author and does not yet appear in
the peer-reviewed literature.

---

## Falsifiable Prediction

I predict that when this pipeline is applied to **raw, un-injected** data from
the 2026 Euclid Heritage Deep Fields and the Rubin LSST Gold Sample, an H₁
persistence feature will manifest near the 1.054 scale (approximately
7 h⁻¹ Mpc) without manual signal injection.

### Criteria for confirmation

1. **Persistence gap:** An H₁ feature must appear with a
   Death / Birth ratio exceeding 1.5, clearly separated from the diagonal
   noise floor.
2. **Harmonic alignment:** Secondary H₁ features should appear near the
   2/7 (~2.86) and 3/7 (~4.29) harmonic modes.

### Criterion for falsification

If the raw 2026 survey data, processed through Yuan 2n3m filtering and Dupke
radial oversampling, yields **only** diagonal noise in the H₁ persistence
diagram at the 1.054 scale, the Tav Topology model at this scale is falsified.

---

## Repository Contents

| File | Description |
|------|-------------|
| `Rubin_LSST_Pipeline_v15.py` | Simulation pipeline (synthetic data + TDA) |
| `v15_Geometric_Tav_Ring_H1_Persistence_Gap.png` | Output figure (three-panel) |
| `README.md` | This file |
| `zenodo_abstract.tex` | LaTeX source for the technical abstract |

---

## How to Cite

```bibtex
@dataset{gatlin_tav_v15_2026,
  author       = {Gatlin, Ernest C., III},
  title        = {Simulated Topological Detection of the 1.054 Berard
                  Constant in Synthetic Rubin LSST Data Streams (v15)},
  year         = {2026},
  publisher    = {Zenodo},
  license      = {CC-BY-4.0},
  note         = {Pre-observation simulation and falsifiable prediction.}
}
```

---

## Requirements

- Python ≥ 3.10
- NumPy
- SciPy
- GUDHI
- Matplotlib
