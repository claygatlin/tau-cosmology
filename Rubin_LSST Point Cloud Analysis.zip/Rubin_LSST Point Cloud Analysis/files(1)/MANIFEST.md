# Supplementary Data Manifest

**Dataset:** Simulated Topological Detection of the 1.054 Berard Constant in Synthetic Rubin LSST Data Streams (v15)
**Author:** Ernest C. Gatlin III
**Date:** March 2026
**License:** CC BY 4.0

---

## File Inventory

| # | Filename | Type | Size | Description |
|---|----------|------|------|-------------|
| 1 | `README.md` | Markdown | ~3 KB | Project overview, methodological note, falsifiable prediction, citation block |
| 2 | `zenodo_abstract.tex` | LaTeX source | ~8 KB | Compilable source for the technical abstract (requires `v15_...png` in same directory) |
| 3 | `zenodo_abstract.pdf` | PDF | ~350 KB | Compiled 3-page document: abstract, pipeline summary, results with Figure 1, falsifiable prediction, Zenodo metadata table, BibTeX, and references |
| 4 | `Rubin_LSST_Pipeline_v15.py` | Python | ~2 KB | Simulation pipeline: synthetic cloud generation, Yuan 2n–3m filtering, Dupke oversampling, GUDHI AlphaComplex persistence computation, three-panel visualisation |
| 5 | `v15_Geometric_Tav_Ring_H1_Persistence_Gap.png` | PNG image | ~180 KB | Three-panel output figure (Tav Ring point cloud, radial resonance histogram, H1 persistence diagram) |

---

## Reproduction Instructions

1. Install dependencies: `pip install numpy scipy gudhi matplotlib`
2. Run `python Rubin_LSST_Pipeline_v15.py` to regenerate the three-panel figure from the synthetic point cloud.
3. To recompile the PDF: place `v15_Geometric_Tav_Ring_H1_Persistence_Gap.png` alongside `zenodo_abstract.tex` and run `pdflatex zenodo_abstract.tex` twice.

---

## Checksums

To verify file integrity after download, run:

```bash
sha256sum README.md zenodo_abstract.tex zenodo_abstract.pdf Rubin_LSST_Pipeline_v15.py v15_Geometric_Tav_Ring_H1_Persistence_Gap.png
```

---

## Contact

Ernest C. Gatlin III — Tau Universe Codex Project
