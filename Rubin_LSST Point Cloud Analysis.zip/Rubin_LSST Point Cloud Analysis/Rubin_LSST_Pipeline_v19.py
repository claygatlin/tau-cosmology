"""
Tau-Yuan-Dupke Pipeline v19 — Density-First, TDA-Confirmed
===========================================================
Author: Ernest C. Gatlin III
Date:   March 2026

Architecture (lessons from v15–v18):
  v15: Preprocessing manufactured artifacts → 100% false positive rate
  v16: No preprocessing → signal invisible (1.08σ, lost in noise)
  v18: Multi-channel approach (partially completed)
  v19: Radial density as PRIMARY discovery tool, TDA as CONFIRMATION

Key insight: A spherical shell at radius r concentrates 4,000 points
in a narrow radial bin. Collapsing 3D→1D (radial histogram) is the
optimal projection for detecting density on a sphere. TDA then
confirms the *topology* of whatever the density test finds.

Detection protocol:
  STEP 1 — Radial density scan (discovery):
    Histogram radial distances. Compare each bin to a smooth
    expectation (r² scaling for uniform cube). Flag bins that
    exceed a significance threshold.

  STEP 2 — Shell extraction + angular TDA (confirmation):
    Extract points in the flagged radial band. Project to unit
    sphere. Run TDA on the angular distribution. A real shell
    should show uniform spherical coverage (strong H2, weak H1).
    A filament or artifact would show anomalous H1.

  STEP 3 — Annular scan (self-calibration):
    Repeat the TDA step at multiple radii within the same dataset.
    The flagged radius must show distinct topology compared to
    non-flagged radii.

  Final detection requires Step 1 + at least one of Steps 2/3.

Usage:
    python Rubin_LSST_Pipeline_v19.py                    # demo run
    python Rubin_LSST_Pipeline_v19.py --blind-test        # full validation
    python Rubin_LSST_Pipeline_v19.py --scan-only         # just radial scan
    python Rubin_LSST_Pipeline_v19.py --target 1.054      # test specific radius

Requirements: numpy, scipy, gudhi, matplotlib
"""

import numpy as np
import gudhi as gd
import matplotlib.pyplot as plt
import argparse
import json
from datetime import datetime


# ============================================================
# 1. POINT CLOUD GENERATORS
# ============================================================

def generate_uniform_background(n_points=15000, box_size=20, seed=None):
    """Uniform random points in a cube (null hypothesis)."""
    rng = np.random.default_rng(seed)
    return (rng.random((n_points, 3)) - 0.5) * box_size


def inject_shell(bg_points, radius, n_shell=4000, seed=None):
    """Add points on a spherical shell at given radius."""
    rng = np.random.default_rng(seed)
    theta = rng.uniform(0, 2 * np.pi, n_shell)
    phi = rng.uniform(0, np.pi, n_shell)
    x = radius * np.sin(phi) * np.cos(theta)
    y = radius * np.sin(phi) * np.sin(theta)
    z = radius * np.cos(phi)
    shell = np.stack([x, y, z], axis=1)
    return np.vstack([bg_points, shell])


# ============================================================
# 2. STEP 1 — RADIAL DENSITY SCAN (Primary Discovery)
# ============================================================

def expected_count_uniform_cube(r_low, r_high, n_total, box_half=10.0):
    """
    Expected number of points in a radial bin [r_low, r_high) for
    uniform-random points in a cube of side 2*box_half.

    For r < box_half, the shell is fully contained and the fraction
    of cube volume in the shell is:
        (4/3 π r_high³ - 4/3 π r_low³) / (2*box_half)³

    For r near the box edge this is approximate but sufficient for
    our radial range (r < ~5, box_half = 10).
    """
    vol_shell = (4.0 / 3.0) * np.pi * (r_high**3 - r_low**3)
    vol_cube = (2 * box_half) ** 3
    fraction = vol_shell / vol_cube
    return n_total * fraction


def radial_density_scan(points, r_min=0.3, r_max=5.0, n_bins=50,
                        n_bg=15000, box_half=10.0):
    """
    Scan radial distances and find significant overdensities.

    Returns a list of bins with their observed count, expected count,
    and significance (sigma).
    """
    radii = np.linalg.norm(points, axis=1)
    bin_edges = np.linspace(r_min, r_max, n_bins + 1)

    bins = []
    for i in range(n_bins):
        r_lo = bin_edges[i]
        r_hi = bin_edges[i + 1]
        r_mid = (r_lo + r_hi) / 2

        observed = np.sum((radii >= r_lo) & (radii < r_hi))
        expected = expected_count_uniform_cube(r_lo, r_hi, n_bg, box_half)

        # Poisson uncertainty on expected count
        poisson_std = np.sqrt(expected) if expected > 0 else 1

        # Significance
        sigma = (observed - expected) / poisson_std if poisson_std > 0 else 0

        bins.append({
            "r_low": round(float(r_lo), 4),
            "r_high": round(float(r_hi), 4),
            "r_mid": round(float(r_mid), 4),
            "observed": int(observed),
            "expected": round(float(expected), 1),
            "poisson_std": round(float(poisson_std), 1),
            "sigma": round(float(sigma), 2),
            "overdensity": round(float(observed / expected), 4) if expected > 0 else 0
        })

    return bins


def find_peaks(bins, sigma_threshold=5.0):
    """Find bins exceeding the significance threshold."""
    peaks = [b for b in bins if b["sigma"] > sigma_threshold]

    # Merge adjacent peaks into clusters
    if not peaks:
        return []

    clusters = []
    current = [peaks[0]]
    for i in range(1, len(peaks)):
        if abs(peaks[i]["r_mid"] - current[-1]["r_mid"]) < \
           2 * (peaks[0]["r_high"] - peaks[0]["r_low"]):
            current.append(peaks[i])
        else:
            clusters.append(current)
            current = [peaks[i]]
    clusters.append(current)

    # Summarize each cluster
    results = []
    for cluster in clusters:
        sigmas = [b["sigma"] for b in cluster]
        results.append({
            "peak_radius": round(float(
                cluster[np.argmax(sigmas)]["r_mid"]), 4),
            "r_range": (cluster[0]["r_low"], cluster[-1]["r_high"]),
            "peak_sigma": round(float(max(sigmas)), 2),
            "total_excess": sum(b["observed"] - b["expected"]
                                for b in cluster),
            "n_bins": len(cluster)
        })

    return results


# ============================================================
# 3. STEP 2 — SHELL-PROJECTED TDA (Confirmation)
# ============================================================

def shell_tda_confirmation(points, peak_radius, band_width=0.3,
                           max_pts=2000, n_null=50, seed=2026):
    """
    Extract points near the peak radius, project to unit sphere,
    run TDA on angular distribution.

    Compare against random uniform distributions on S² with the
    same number of points (null = isotropic shell).

    A REAL uniform shell should look LIKE the null (isotropic).
    A PIPELINE ARTIFACT or non-shell structure should deviate.

    We measure:
      - H1 count and persistence (loops on the sphere)
      - H2 presence (confirms closed-sphere topology)
    """
    rng = np.random.default_rng(seed)
    radii = np.linalg.norm(points, axis=1)

    # Extract band
    r_lo = peak_radius - band_width / 2
    r_hi = peak_radius + band_width / 2
    mask = (radii >= r_lo) & (radii < r_hi)
    shell_pts = points[mask]

    if len(shell_pts) < 30:
        return {
            "status": "insufficient_points",
            "n_shell_points": len(shell_pts),
            "confirmed": False
        }

    # Project to unit sphere
    norms = np.linalg.norm(shell_pts, axis=1, keepdims=True)
    angular_pts = shell_pts / norms

    if len(angular_pts) > max_pts:
        idx = rng.choice(len(angular_pts), max_pts, replace=False)
        angular_pts = angular_pts[idx]

    n_pts = len(angular_pts)

    # Signal TDA
    sig_h1, sig_h2 = _sphere_tda(angular_pts)

    # Null distribution: uniform random on S²
    null_h1_pers = []
    null_h2_count = []
    for i in range(n_null):
        null_pts = rng.normal(0, 1, (n_pts, 3))
        null_pts = null_pts / np.linalg.norm(null_pts, axis=1, keepdims=True)
        nh1, nh2 = _sphere_tda(null_pts)
        null_h1_pers.append(nh1["max_persistence"])
        null_h2_count.append(nh2["count"])

    null_h1_mean = np.mean(null_h1_pers)
    null_h1_std = np.std(null_h1_pers)
    null_h2_mean = np.mean(null_h2_count)

    # A real shell should have H1 stats CONSISTENT with null
    # (i.e., it looks like a sphere). Anomalous H1 means non-shell structure.
    h1_sigma = ((sig_h1["max_persistence"] - null_h1_mean) / null_h1_std
                if null_h1_std > 0 else 0)

    # H2 presence confirms sphere-like topology
    has_h2 = sig_h2["count"] > 0

    # "Confirmed" means: density peak exists AND angular distribution
    # is consistent with a spherical shell (not anomalous H1, has H2)
    is_shell_like = (abs(h1_sigma) < 3.0)  # H1 not anomalous

    return {
        "status": "complete",
        "n_shell_points": len(shell_pts),
        "n_angular_pts": n_pts,
        "signal_h1_max_persistence": round(sig_h1["max_persistence"], 6),
        "signal_h1_count": sig_h1["count"],
        "signal_h2_count": sig_h2["count"],
        "null_h1_mean": round(float(null_h1_mean), 6),
        "null_h1_std": round(float(null_h1_std), 6),
        "h1_sigma": round(float(h1_sigma), 2),
        "has_h2": has_h2,
        "is_shell_like": is_shell_like,
        "confirmed": is_shell_like  # angular distribution matches shell
    }


def _sphere_tda(pts):
    """Run GUDHI on points and return H1 and H2 summaries."""
    ac = gd.AlphaComplex(points=pts)
    st = ac.create_simplex_tree()
    persistence = st.persistence(homology_coeff_field=2, min_persistence=0.0001)

    h1_pers = []
    h2_pers = []
    for dim, (birth, death) in persistence:
        if death == float('inf'):
            continue
        if dim == 1:
            h1_pers.append(death - birth)
        elif dim == 2:
            h2_pers.append(death - birth)

    h1 = {
        "max_persistence": max(h1_pers) if h1_pers else 0,
        "count": len(h1_pers)
    }
    h2 = {
        "max_persistence": max(h2_pers) if h2_pers else 0,
        "count": len(h2_pers)
    }
    return h1, h2


# ============================================================
# 4. STEP 3 — ANNULAR SELF-CALIBRATION
# ============================================================

def annular_self_calibration(points, peak_radius, n_test_radii=15,
                             r_min=0.5, r_max=4.0, band_width=0.3,
                             max_pts=1500, seed=2026):
    """
    Run shell-projected TDA at many radii within the same dataset.
    The peak radius should show a DENSER angular distribution
    (more points on the shell) than non-peak radii.

    This isn't about H1 anymore — it's about whether the angular
    point density at the peak radius is anomalously high compared
    to other radii, confirming the radial density finding with
    an independent geometric measurement.
    """
    rng = np.random.default_rng(seed)
    radii = np.linalg.norm(points, axis=1)
    test_radii = np.linspace(r_min, r_max, n_test_radii)

    scan = []
    for r_test in test_radii:
        r_lo = r_test - band_width / 2
        r_hi = r_test + band_width / 2
        mask = (radii >= r_lo) & (radii < r_hi)
        n_in_band = np.sum(mask)

        # Expected count for this band (uniform cube)
        expected = expected_count_uniform_cube(r_lo, r_hi, 15000, 10.0)
        excess = n_in_band - expected

        # Also run quick H1 check
        band_pts = points[mask]
        if len(band_pts) > 30:
            norms = np.linalg.norm(band_pts, axis=1, keepdims=True)
            ang = band_pts / norms
            if len(ang) > max_pts:
                idx = rng.choice(len(ang), max_pts, replace=False)
                ang = ang[idx]
            h1, h2 = _sphere_tda(ang)
            h1_pers = h1["max_persistence"]
            h2_count = h2["count"]
        else:
            h1_pers = 0
            h2_count = 0

        scan.append({
            "radius": round(float(r_test), 4),
            "n_in_band": int(n_in_band),
            "expected": round(float(expected), 1),
            "excess": round(float(excess), 1),
            "h1_max_persistence": round(float(h1_pers), 6),
            "h2_present": h2_count > 0
        })

    # Find where peak_radius sits
    cand_idx = np.argmin(np.abs(test_radii - peak_radius))
    cand_excess = scan[cand_idx]["excess"]

    other_excess = [s["excess"] for i, s in enumerate(scan) if i != cand_idx]
    other_mean = np.mean(other_excess)
    other_std = np.std(other_excess)
    sigma = (cand_excess - other_mean) / other_std if other_std > 0 else 0

    return {
        "candidate_radius": round(float(peak_radius), 4),
        "candidate_excess": round(float(cand_excess), 1),
        "other_mean_excess": round(float(other_mean), 1),
        "other_std_excess": round(float(other_std), 1),
        "sigma": round(float(sigma), 2),
        "confirmed": sigma > 3.0,
        "scan": scan
    }


# ============================================================
# 5. FULL DETECTION PROTOCOL
# ============================================================

def run_detection(points, target_radius=None, n_bg=15000,
                  label="", verbose=True):
    """
    Full v19 detection protocol.

    If target_radius is given, test that specific radius.
    Otherwise, scan for peaks and test the strongest one.
    """
    if verbose:
        print(f"\n{'═' * 60}")
        print(f"  v19 Detection: {label}")
        print(f"  Points: {len(points)}")
        if target_radius:
            print(f"  Target radius: {target_radius}")
        print(f"{'═' * 60}")

    # STEP 1: Radial density scan
    bins = radial_density_scan(points, n_bg=n_bg)
    peaks = find_peaks(bins, sigma_threshold=5.0)

    if verbose:
        print(f"\n  STEP 1 — Radial Density Scan")
        print(f"  Peaks found (>5σ): {len(peaks)}")
        for p in peaks:
            print(f"    r = {p['peak_radius']:.3f}, "
                  f"σ = {p['peak_sigma']:.1f}, "
                  f"excess = {p['total_excess']:.0f} points")

    # Determine which radius to test
    if target_radius is not None:
        # Check if any peak is near the target
        test_radius = target_radius
        density_detected = any(
            abs(p["peak_radius"] - target_radius) < 0.3
            for p in peaks
        )
        if density_detected:
            matching = [p for p in peaks
                        if abs(p["peak_radius"] - target_radius) < 0.3]
            density_sigma = max(p["peak_sigma"] for p in matching)
        else:
            # Run focused test at target radius even if no peak
            focused_bins = radial_density_scan(
                points, r_min=target_radius - 0.5,
                r_max=target_radius + 0.5, n_bins=20, n_bg=n_bg
            )
            focused_peaks = find_peaks(focused_bins, sigma_threshold=5.0)
            density_detected = len(focused_peaks) > 0
            density_sigma = (max(p["peak_sigma"] for p in focused_peaks)
                             if focused_peaks else 0)
    elif peaks:
        test_radius = peaks[0]["peak_radius"]
        density_detected = True
        density_sigma = peaks[0]["peak_sigma"]
    else:
        if verbose:
            print(f"\n  No density peaks found. Stopping.")
            print(f"  Verdict: NO DETECTION")
        return {
            "label": label,
            "step1_density": {"detected": False, "peaks": []},
            "step2_tda": None,
            "step3_selfcal": None,
            "detected": False,
            "channels_passed": 0
        }

    if verbose:
        print(f"\n  Testing radius: {test_radius:.3f}")
        print(f"  Density detected: {density_detected} "
              f"(σ = {density_sigma:.1f})")

    # STEP 2: Shell TDA confirmation
    if verbose:
        print(f"\n  STEP 2 — Shell-Projected TDA Confirmation")
    tda_result = shell_tda_confirmation(points, test_radius)

    if verbose:
        if tda_result["status"] == "complete":
            print(f"  Shell points: {tda_result['n_shell_points']}")
            print(f"  H1 sigma:     {tda_result['h1_sigma']} "
                  f"(want |σ| < 3 for shell)")
            print(f"  H2 present:   {tda_result['has_h2']}")
            print(f"  Shell-like:   {tda_result['is_shell_like']}")
        else:
            print(f"  Status: {tda_result['status']}")

    # STEP 3: Annular self-calibration
    if verbose:
        print(f"\n  STEP 3 — Annular Self-Calibration")
    selfcal = annular_self_calibration(points, test_radius)

    if verbose:
        print(f"  Candidate excess: {selfcal['candidate_excess']} points")
        print(f"  Other radii:      {selfcal['other_mean_excess']} "
              f"± {selfcal['other_std_excess']}")
        print(f"  Sigma:            {selfcal['sigma']}")
        print(f"  Confirmed:        {selfcal['confirmed']}")

    # COMBINED VERDICT
    # Requires: density peak (Step 1) + at least one confirmation (Step 2 or 3)
    tda_confirmed = (tda_result.get("confirmed", False)
                     if tda_result["status"] == "complete" else False)
    selfcal_confirmed = selfcal["confirmed"]

    channels = sum([density_detected, tda_confirmed, selfcal_confirmed])
    detected = density_detected and (tda_confirmed or selfcal_confirmed)

    if verbose:
        flags = (f"{'D' if density_detected else '.'}"
                 f"{'T' if tda_confirmed else '.'}"
                 f"{'S' if selfcal_confirmed else '.'}")

        print(f"\n  ╔════════════════════════════════════════════╗")
        print(f"  ║  Channels [{flags}]: {channels}/3"
              f"{'':>24}║")
        print(f"  ║  Density σ = {density_sigma:<8.1f}"
              f"{'':>23}║")
        if detected:
            print(f"  ║  ★ DETECTION at r ≈ {test_radius:<8.3f}"
                  f"{'':>15}║")
        else:
            print(f"  ║  No detection (consistent with noise)"
                  f"{'':>4}║")
        print(f"  ╚════════════════════════════════════════════╝")

    return {
        "label": label,
        "test_radius": test_radius,
        "step1_density": {
            "detected": density_detected,
            "sigma": density_sigma,
            "peaks": peaks
        },
        "step2_tda": tda_result,
        "step3_selfcal": {
            "confirmed": selfcal_confirmed,
            "sigma": selfcal["sigma"]
        },
        "channels_passed": channels,
        "detected": detected
    }


# ============================================================
# 6. BLIND VALIDATION SUITE
# ============================================================

def run_blind_suite():
    """Comprehensive blind test."""
    rng = np.random.default_rng(4242)
    trials = []

    # 8 null (no signal at all)
    for i in range(8):
        s = int(rng.integers(0, 10_000_000))
        pts = generate_uniform_background(seed=s)
        trials.append((pts, "null", None, 0, f"null_{i}"))

    # 4 signal at 1.054 (full strength — what we predict)
    for i in range(4):
        sb = int(rng.integers(0, 10_000_000))
        ss = int(rng.integers(0, 10_000_000))
        pts = inject_shell(generate_uniform_background(seed=sb),
                           1.054, 4000, seed=ss)
        trials.append((pts, "signal", 1.054, 4000, f"sig1054_{i}"))

    # 4 decoy radii (shells exist, but NOT at 1.054)
    for r in [0.6, 1.5, 2.5, 4.0]:
        sb = int(rng.integers(0, 10_000_000))
        ss = int(rng.integers(0, 10_000_000))
        pts = inject_shell(generate_uniform_background(seed=sb),
                           r, 4000, seed=ss)
        trials.append((pts, "decoy", r, 4000, f"decoy_r{r}"))

    # 3 weak signals at 1.054 (can the pipeline see faint shells?)
    for n_sh in [500, 1000, 2000]:
        sb = int(rng.integers(0, 10_000_000))
        ss = int(rng.integers(0, 10_000_000))
        pts = inject_shell(generate_uniform_background(seed=sb),
                           1.054, n_sh, seed=ss)
        trials.append((pts, "weak", 1.054, n_sh, f"weak_n{n_sh}"))

    # Shuffle
    indices = list(range(len(trials)))
    rng.shuffle(indices)

    print("\n" + "=" * 80)
    print("  v19 BLIND VALIDATION SUITE")
    print("  Testing every trial at target radius = 1.054")
    print("=" * 80)

    all_results = []

    for rank, idx in enumerate(indices):
        pts, truth_type, truth_r, truth_n, name = trials[idx]

        result = run_detection(pts, target_radius=1.054,
                               label=name, verbose=False)

        # Classify:  "positive" = signal or weak at r=1.054
        #            "negative" = null or decoy at other radius
        is_positive = (truth_type in ["signal", "weak"]) and truth_r == 1.054
        detected = result["detected"]

        if is_positive and detected:
            tag = "TP"
        elif is_positive and not detected:
            tag = "FN"
        elif not is_positive and detected:
            tag = "FP"
        else:
            tag = "TN"

        d_sig = result["step1_density"]["sigma"]
        t_sig = (result["step2_tda"]["h1_sigma"]
                 if result["step2_tda"] and
                 result["step2_tda"]["status"] == "complete" else 0)
        s_sig = result["step3_selfcal"]["sigma"] if result["step3_selfcal"] else 0

        d_flag = "D" if result["step1_density"]["detected"] else "."
        t_flag = ("T" if result["step2_tda"] and
                  result["step2_tda"].get("confirmed") else ".")
        s_flag = ("S" if result["step3_selfcal"] and
                  result["step3_selfcal"].get("confirmed") else ".")

        truth_str = f"{truth_type}"
        if truth_r:
            truth_str += f" r={truth_r}"
        if truth_n:
            truth_str += f" n={truth_n}"

        print(f"  {name:<14} [{d_flag}{t_flag}{s_flag}] "
              f"Dσ={d_sig:>7.1f}  Tσ={t_sig:>6.1f}  Sσ={s_sig:>6.1f}  "
              f"{'DETECT' if detected else 'noise ':>6}  "
              f"{truth_str:<26} {tag}")

        all_results.append({
            "name": name, "truth_type": truth_type,
            "truth_radius": truth_r, "truth_n_shell": truth_n,
            "detected": detected, "tag": tag,
            "density_sigma": d_sig,
            "tda_sigma": t_sig,
            "selfcal_sigma": s_sig
        })

    # Summary
    tp = sum(1 for r in all_results if r["tag"] == "TP")
    fp = sum(1 for r in all_results if r["tag"] == "FP")
    tn = sum(1 for r in all_results if r["tag"] == "TN")
    fn = sum(1 for r in all_results if r["tag"] == "FN")

    sens = tp / (tp + fn) if (tp + fn) > 0 else 0
    spec = tn / (tn + fp) if (tn + fp) > 0 else 0
    fpr = fp / (fp + tn) if (fp + tn) > 0 else 0

    print(f"\n{'─' * 80}")
    print(f"  SUMMARY")
    print(f"  True Positives:   {tp}   (1.054 shells detected)")
    print(f"  False Positives:  {fp}   (null/decoy wrongly detected at 1.054)")
    print(f"  True Negatives:   {tn}   (null/decoy correctly quiet)")
    print(f"  False Negatives:  {fn}   (1.054 shells missed)")
    print(f"")
    print(f"  Sensitivity:      {sens:.0%}")
    print(f"  Specificity:      {spec:.0%}")
    print(f"  False pos rate:   {fpr:.0%}")
    print(f"{'─' * 80}")

    print(f"\n  KEY QUESTIONS:")
    print(f"  1. Null trials quiet?        FP = {fp} (want 0)")
    print(f"  2. 1.054 signals detected?   TP = {tp}/{tp+fn}")
    print(f"  3. Decoys at wrong radius?   (should be TN, not FP)")
    print(f"  4. Weak signals detected?    (sensitivity floor)")

    # Save
    output = {
        "timestamp": datetime.now().isoformat(),
        "pipeline_version": "v19",
        "summary": {"tp": tp, "fp": fp, "tn": tn, "fn": fn,
                     "sensitivity": sens, "specificity": spec},
        "trials": all_results
    }
    with open("v19_blind_results.json", "w") as f:
        json.dump(output, f, indent=2)
    print(f"\n  Results saved to v19_blind_results.json")

    return output


# ============================================================
# 7. VISUALIZATION
# ============================================================

def plot_v19_summary(points, result, save_path=None):
    """Four-panel v19 summary figure."""
    fig = plt.figure(figsize=(20, 10))

    # --- Panel 1: Radial histogram with peaks marked ---
    ax1 = fig.add_subplot(221)
    radii = np.linalg.norm(points, axis=1)
    counts, edges, patches = ax1.hist(
        radii, bins=80, range=(0, 5),
        color="steelblue", alpha=0.7, edgecolor="navy", linewidth=0.3
    )

    # Overlay expected curve
    r_mids = 0.5 * (edges[:-1] + edges[1:])
    dr = edges[1] - edges[0]
    expected = [expected_count_uniform_cube(r_mids[i] - dr/2,
                r_mids[i] + dr/2, 15000, 10.0) for i in range(len(r_mids))]
    ax1.plot(r_mids, expected, 'k--', linewidth=1.5, label="Expected (uniform)")

    for p in result["step1_density"]["peaks"]:
        ax1.axvline(p["peak_radius"], color="red", linewidth=2,
                    linestyle="--", alpha=0.8)
        ax1.annotate(f'σ={p["peak_sigma"]:.0f}',
                     xy=(p["peak_radius"], max(counts) * 0.9),
                     fontsize=10, color="red", fontweight="bold")

    ax1.set_xlabel("Radial Distance", fontsize=11)
    ax1.set_ylabel("Count", fontsize=11)
    ax1.set_title("Step 1: Radial Density Scan", fontsize=12)
    ax1.legend(fontsize=10)

    # --- Panel 2: Significance vs radius ---
    ax2 = fig.add_subplot(222)
    bins = radial_density_scan(points)
    r_mids = [b["r_mid"] for b in bins]
    sigmas = [b["sigma"] for b in bins]
    colors = ["red" if s > 5 else "steelblue" for s in sigmas]
    ax2.bar(r_mids, sigmas, width=(r_mids[1] - r_mids[0]) * 0.9,
            color=colors, alpha=0.7, edgecolor="navy", linewidth=0.3)
    ax2.axhline(5.0, color="red", linestyle=":", linewidth=1.5,
                label="5σ threshold")
    ax2.axhline(0, color="black", linewidth=0.5)
    ax2.set_xlabel("Radial Distance", fontsize=11)
    ax2.set_ylabel("Significance (σ)", fontsize=11)
    ax2.set_title("Step 1: Bin-by-Bin Significance", fontsize=12)
    ax2.legend(fontsize=10)

    # --- Panel 3: Point cloud (top-down view) ---
    ax3 = fig.add_subplot(223)
    mask_z = np.abs(points[:, 2]) < 0.5
    thin_pts = points[mask_z]
    if len(thin_pts) > 5000:
        idx = np.random.choice(len(thin_pts), 5000, replace=False)
        thin_pts = thin_pts[idx]
    ax3.scatter(thin_pts[:, 0], thin_pts[:, 1], s=1, alpha=0.3,
                color="steelblue")

    if result["step1_density"]["detected"]:
        r = result["test_radius"]
        theta_circle = np.linspace(0, 2 * np.pi, 200)
        ax3.plot(r * np.cos(theta_circle), r * np.sin(theta_circle),
                 'r-', linewidth=2, label=f"r = {r:.3f}")
        ax3.legend(fontsize=10)

    ax3.set_xlabel("X", fontsize=11)
    ax3.set_ylabel("Y", fontsize=11)
    ax3.set_title("Top-Down Slice (|z| < 0.5)", fontsize=12)
    ax3.set_aspect("equal")

    # --- Panel 4: Self-calibration scan ---
    ax4 = fig.add_subplot(224)
    if (result["step3_selfcal"] and
            "scan" in result.get("_selfcal_full", {})):
        scan = result["_selfcal_full"]["scan"]
    else:
        # Re-run for plotting
        selfcal = annular_self_calibration(points, result.get("test_radius", 1.054))
        scan = selfcal["scan"]

    scan_r = [s["radius"] for s in scan]
    scan_excess = [s["excess"] for s in scan]
    test_r = result.get("test_radius", 1.054)
    cand_idx = np.argmin(np.abs(np.array(scan_r) - test_r))
    bar_colors = ["red" if i == cand_idx else "steelblue"
                  for i in range(len(scan_r))]

    ax4.bar(scan_r, scan_excess,
            width=(scan_r[1] - scan_r[0]) * 0.8,
            color=bar_colors, alpha=0.7, edgecolor="navy", linewidth=0.3)
    ax4.set_xlabel("Radius", fontsize=11)
    ax4.set_ylabel("Excess Points vs Expected", fontsize=11)
    ax4.set_title("Step 3: Self-Calibration Scan", fontsize=12)
    ax4.axhline(0, color="black", linewidth=0.5)

    # Suptitle
    verdict = "DETECTED" if result["detected"] else "No Detection"
    plt.suptitle(f"v19 Pipeline Summary: {result['label']} — {verdict}",
                 fontsize=14, fontweight="bold", y=1.01)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"  Plot saved to {save_path}")
    plt.show()

    return fig


# ============================================================
# 8. MAIN
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="Tau-Yuan-Dupke Pipeline v19"
    )
    parser.add_argument("--blind-test", action="store_true",
                        help="Run full blind validation suite")
    parser.add_argument("--scan-only", action="store_true",
                        help="Only run radial density scan")
    parser.add_argument("--target", type=float, default=None,
                        help="Target radius to test (default: auto-detect)")
    parser.add_argument("--no-plot", action="store_true",
                        help="Skip visualization")
    args = parser.parse_args()

    print("=" * 60)
    print("  TAU-YUAN-DUPKE PIPELINE v19")
    print("  Density-First, TDA-Confirmed")
    print(f"  {datetime.now().isoformat()}")
    print("=" * 60)

    if args.blind_test:
        run_blind_suite()
        return

    # Demo: signal vs noise
    print("\n━━━ TEST A: Planted shell at r = 1.054 ━━━")
    bg = generate_uniform_background(seed=1054)
    signal_pts = inject_shell(bg, radius=1.054, n_shell=4000, seed=2026)
    sig_result = run_detection(signal_pts, target_radius=args.target,
                               label="Shell at r=1.054 (n=4000)")

    print("\n━━━ TEST B: Pure noise (no shell) ━━━")
    noise_pts = generate_uniform_background(seed=9999)
    noise_result = run_detection(noise_pts, target_radius=args.target or 1.054,
                                 label="Pure noise")

    # Assessment
    print(f"\n{'═' * 60}")
    print("  v19 ASSESSMENT")
    print(f"{'═' * 60}")
    if sig_result["detected"] and not noise_result["detected"]:
        print("  ★ SUCCESS: Signal detected, noise rejected")
    elif sig_result["detected"] and noise_result["detected"]:
        print("  ✗ FAIL: Both signal and noise trigger (false positive problem)")
    elif not sig_result["detected"] and not noise_result["detected"]:
        print("  ~ INCONCLUSIVE: Neither detected")
        print("    Signal may be too weak, or detection thresholds too strict")
    else:
        print("  ✗ INVERTED: Noise triggers but signal doesn't")

    # Visualization
    if not args.no_plot:
        try:
            plot_v19_summary(signal_pts, sig_result,
                             save_path="v19_signal_summary.png")
            plot_v19_summary(noise_pts, noise_result,
                             save_path="v19_noise_summary.png")
        except Exception as e:
            print(f"  Plots skipped: {e}")


if __name__ == "__main__":
    main()
