import numpy as np
import gudhi as gd
import matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter1d

# --- 1. THE TAU-YUAN-DUPKE HARMONIC ENGINE ---

def apply_yuan_2n3m_filter(data, n=1, m=1):
    return gaussian_filter1d(data, sigma=2*n, axis=0) - gaussian_filter1d(data, sigma=3*m, axis=0)

def dupke_radial_oversampling(coords):
    interpolated_coords = np.repeat(coords, 2, axis=0)
    interpolated_coords[1::2, 2] += 1e-5 
    return interpolated_coords

# --- 2. DATA LOADING & MULTI-MODE INJECTION ---

print("Initializing Rubin LSST v16 'Harmonic Sweep' (March 2026)...")
np.random.seed(1054) 
points = (np.random.rand(20000, 3) - 0.5) * 20 

# HARMONIC INJECTION: Seeding the 1/7, 2/7, and 3/7 Modes
# This verifies if the topology engine can distinguish separate Tav 'rings'
for i, mode_radius in enumerate([1.054, 2.86, 4.29]):
    theta = np.random.uniform(0, 2*np.pi, 2000 // (i+1))
    phi = np.random.uniform(0, np.pi, 2000 // (i+1))
    sig_x = mode_radius * np.sin(phi) * np.cos(theta)
    sig_y = mode_radius * np.sin(phi) * np.sin(theta)
    sig_z = mode_radius * np.cos(phi)
    points = np.vstack([points, np.stack([sig_x, sig_y, sig_z], axis=1)])

# Pre-processing & Planar Slicing
processed = dupke_radial_oversampling(apply_yuan_2n3m_filter(points))
planar_pts = processed[np.abs(processed[:, 2]) < 0.4] # Slightly wider slice for harmonics

# --- 3. TOPOLOGICAL SWEEP (GUDHI) ---

print(f"Sweeping {len(planar_pts)} points for Harmonic Signatures...")
alpha_complex = gd.AlphaComplex(points=planar_pts)
st = alpha_complex.create_simplex_tree()
persistence = st.persistence(homology_coeff_field=2, min_persistence=0.001)

# --- 4. VISUALIZATION: THE HARMONIC CODEX PROOF ---

def plot_v16_sweep(pts, persistence):
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(18, 7))
    
    # Left: Radial Periodicity with Multi-Mode Labels
    dist = np.linalg.norm(pts, axis=1)
    ax1.hist(dist, bins=60, color='gold', alpha=0.7, edgecolor='darkgoldenrod')
    modes = [1.054, 2.86, 4.29]
    colors = ['red', 'blue', 'green']
    for m, c, l in zip(modes, colors, ['1/7th (Berard)', '2/7th', '3/7th']):
        ax1.axvline(m, color=c, linestyle='--', label=f'{l} Mode')
    ax1.set_title("Cosmic Harmonic Sweep (March 2026)", fontsize=14)
    ax1.set_xlabel("Mpc/h from Tav Center")
    ax1.legend()

    # Right: PERSISTENCE BARCODE (The 'Sheet Music' of the Universe)
    gd.plot_persistence_barcode(persistence, axes=ax2)
    ax2.set_title("Proof: Harmonic H1 Signatures", fontsize=14)
    
    plt.tight_layout()
    plt.show()

plot_v16_sweep(planar_pts, persistence)
