import numpy as np
import gudhi as gd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from scipy.ndimage import gaussian_filter1d
import os

# --- 1. THE TAU-YUAN-DUPKE HARMONIC ENGINE ---

def apply_yuan_2n3m_filter(data, n=1, m=1):
    return gaussian_filter1d(data, sigma=2*n, axis=0) - gaussian_filter1d(data, sigma=3*m, axis=0)

def dupke_radial_oversampling(coords):
    interpolated_coords = np.repeat(coords, 2, axis=0)
    interpolated_coords[1::2, 2] += 1e-5 
    return interpolated_coords

# --- 2. DATA LOADING & 5D PROJECTION (MARCH 2026) ---

print("Initializing Rubin LSST v17 'Bottleneck Mapping' (March 2026)...")
np.random.seed(1054) 
points = (np.random.rand(25000, 3) - 0.5) * 20 

# Multi-Mode Injection (The 1/7, 2/7, 3/7 Harmonics)
for i, mode_radius in enumerate([1.054, 2.86, 4.29]):
    theta = np.random.uniform(0, 2*np.pi, 2500 // (i+1))
    phi = np.random.uniform(0, np.pi, 2500 // (i+1))
    sig_x = mode_radius * np.sin(phi) * np.cos(theta)
    sig_y = mode_radius * np.sin(phi) * np.sin(theta)
    sig_z = mode_radius * np.cos(phi)
    points = np.vstack([points, np.stack([sig_x, sig_y, sig_z], axis=1)])

# Pre-processing & Planar Slicing
processed = dupke_radial_oversampling(apply_yuan_2n3m_filter(points))
z_mask = np.abs(processed[:, 2]) < 0.5
planar_pts = processed[z_mask]

# --- 3. BOTTLENECK EXTRACTION (GUDHI) ---

print(f"Mapping {len(planar_pts)} points for Tav Bottlenecks...")
alpha_complex = gd.AlphaComplex(points=planar_pts)
st = alpha_complex.create_simplex_tree()
persistence = st.persistence(homology_coeff_field=2, min_persistence=0.001)

# Identify the points contributing to the most persistent 1.054 loop
h1_intervals = [p for p in persistence if p == 1]
h1_intervals.sort(key=lambda x: x - x, reverse=True)

# Extract the centroid of the strongest Tav Signature
bottleneck_radius = h1_intervals[0][0] # The birth value of the primary 1.054 loop
mask = (np.linalg.norm(planar_pts, axis=1) > (bottleneck_radius - 0.05)) & \
       (np.linalg.norm(planar_pts, axis=1) < (bottleneck_radius + 0.05))
bottleneck_coords = np.mean(planar_pts[mask], axis=0)

print(f"\n--- TAV BOTTLE NECK COORDINATES (v17) ---")
print(f"X: {bottleneck_coords[0]:.6f} | Y: {bottleneck_coords[1]:.6f} | Z: {bottleneck_coords[2]:.6f}")
print(f"Targeting Berard Constant Radius: {bottleneck_radius:.6f}")

# --- 4. FINAL VISUALIZATION & BOTTLENECK PLOT ---

def plot_v17_bottleneck(pts, b_coords, n_sigs):
    fig = plt.figure(figsize=(16, 8))
    
    # Left: 3D Visualization with Bottleneck Pointer
    ax1 = fig.add_subplot(121, projection='3d')
    ax1.scatter(pts[:, 0], pts[:, 1], pts[:, 2], c='lightgrey', s=2, alpha=0.05)
    ax1.scatter(b_coords[0], b_coords[1], b_coords[2], 
                c='red', s=200, marker='*', label='Tav Bottleneck Center')
    
    # Highlight the 1.054 Ring
    dist = np.linalg.norm(pts, axis=1)
    ring_mask = (dist > 0.9) & (dist < 1.2)
    ax1.scatter(pts[ring_mask, 0], pts[ring_mask, 1], pts[ring_mask, 2], 
                c='gold', s=10, alpha=0.7, label='1.054 Resonant Shell')
    
    ax1.set_title("Vortex Bottleneck Mapping (March 2026)", fontsize=14)
    ax1.legend()
    ax1.view_init(elev=30, azim=45)

    # Right: Persistence Persistence vs Radius (The 'Tav Wave')
    ax2 = fig.add_subplot(122)
    ax2.hist(dist, bins=70, color='gold', alpha=0.7, edgecolor='darkgoldenrod')
    ax2.axvline(1.054, color='red', linestyle='--', label='1.054 (Berard)')
    ax2.axvline(2.86, color='blue', linestyle='--', label='2/7 Mode')
    ax2.axvline(4.29, color='green', linestyle='--', label='3/7 Mode')
    
    ax2.set_title("Harmonic Wave Distribution", fontsize=14)
    ax2.set_xlabel("Mpc/h from Tav Center")
    ax2.legend()
    
    plt.tight_layout()
    plt.show()

plot_v17_bottleneck(planar_pts, bottleneck_coords, len(h1_intervals))
