# Simulated Topological Detection of the 1.054 Berard Constant (v19.1)

**Author:** Ernest C. Gatlin III
**Date:** March 2026
**License:** [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)
**Original deposit:** [DOI 10.5281/zenodo.18880631](https://doi.org/10.5281/zenodo.18880631)

---

## Overview

This deposit contains a validated detection pipeline (v19.1) for
identifying radial overdensities in 3D point clouds, developed as part
of the Tav Topology programme. It supersedes the v15 pipeline from the
original Zenodo deposit after blind testing revealed critical flaws in
that version's preprocessing.

**This remains a simulation and pipeline validation, not a detection
claim.** All tests use synthetic point clouds with planted signals. The
pipeline is registered here in advance of application to real 2026
survey data.

All named constructs (Berard Constant, Tav Ring, Tau-Yuan-Dupke
Pipeline) are original terminology introduced by the author and do not
appear in the peer-reviewed literature.

---

## What Changed from v15

The v15 pipeline applied Yuan 2n-3m filtering, planar slicing, and
core excision before running GUDHI persistent homology. Blind testing
(21 trials) revealed a 100% false positive rate: those preprocessing
steps carved an annular geometry from any input, topologically
guaranteeing the H1 feature the pipeline claimed to detect. A
step-by-step diagnostic confirmed that even raw noise exceeded the
Death/Birth > 1.5 threshold by a factor of 100.

The v19.1 pipeline replaces the entire architecture:

- **v15:** Preprocessing-first, TDA-only, single threshold
- **v19.1:** Density-first discovery, TDA confirmation, self-calibrated

Development history: v15 (artifact) -> v16 (signal invisible) ->
diagnostic (bug found) -> v19 (working detector) -> v19.1 (JSON fix).

---

## v19.1 Pipeline Architecture

Detection proceeds in three stages:

**Step 1 — Radial Density Scan (discovery).** Histogram all radial
distances from the origin. Compare each bin to the analytical expected
count for a uniform cube (r-squared shell volume scaling). Flag bins
exceeding 5 sigma.

**Step 2 — Shell-Projected TDA (confirmation).** Extract points in the
flagged radial band. Project onto the unit sphere. Run GUDHI
AlphaComplex on the angular distribution and compare against random
uniform distributions on S-squared. Confirms whether the overdensity
has shell-like topology.

**Step 3 — Annular Self-Calibration.** Repeat the density and TDA
analysis at 15 radii across the dataset. The flagged radius must show
excess points significantly above all other radii. This controls for
geometric artifacts by using the dataset as its own null.

**Detection requires:** Step 1 trigger plus at least one of Steps 2/3.

---

## Validation Results

| Test                        | Result                          |
|-----------------------------|---------------------------------|
| Blind suite (19 trials)     | 7 TP, 12 TN, 0 FP, 0 FN       |
| Sensitivity                 | 100%                            |
| Specificity                 | 100%                            |
| Harmonic sweep (injected)   | 10/10 modes detected            |
| Harmonic sweep (null)       | 0/10 false detections           |
| Weakest signal detected     | 500 shell points in 15,000 bg   |

---

## Falsifiable Prediction (unchanged from v15)

When applied to raw, un-injected 2026 Euclid Heritage Deep Field or
Rubin LSST Gold Sample data, the pipeline should detect a radial
overdensity near the 1.054 normalized scale (approximately 7 h-1 Mpc)
without manual signal injection.

**Confirmation criteria:**
1. A radial density peak exceeding 5 sigma at the 1.054 scale
2. Self-calibration sigma exceeding 3.0 at that radius

**Falsification criterion:**
If only noise-level counts appear at the 1.054 scale after processing
the 2026 survey data, the Tav Topology model at this scale is falsified.

---

## Repository Contents

| File | Description |
|------|-------------|
| `Rubin_LSST_Pipeline_v19.1.py` | Complete pipeline with blind suite |
| `v19_blind_results.json` | Machine-readable blind suite results (19 trials) |
| `harmonic_sweep.py` | Harmonic sweep script (injection + null modes) |
| `harmonic_sweep_results.json` | Injection sweep: 10/10 detected |
| `harmonic_sweep_null_results.json` | Null sweep: 0/10 false positives |
| `v19_signal_summary.png` | Four-panel signal detection figure |
| `v19_noise_summary.png` | Four-panel noise rejection figure |
| `README.md` | This file |

---

## Reproduction

**Requirements:** Python 3.10+, NumPy, SciPy, GUDHI, Matplotlib

**Run the blind suite:**
```
pip install numpy scipy gudhi matplotlib
python3 Rubin_LSST_Pipeline_v19.1.py --blind-test
```

**Run the harmonic sweep:**
```
python3 harmonic_sweep.py
python3 harmonic_sweep.py --no-inject
```

**Run the demo (signal vs noise):**
```
python3 Rubin_LSST_Pipeline_v19.1.py
```

---

## How to Cite

```bibtex
@dataset{gatlin_tav_v19_2026,
  author       = {Gatlin, Ernest C., III},
  title        = {Simulated Topological Detection of the 1.054
                  Berard Constant in Synthetic Rubin LSST
                  Data Streams (v19.1)},
  year         = {2026},
  publisher    = {Zenodo},
  doi          = {10.5281/zenodo.18880631},
  license      = {CC-BY-4.0},
  note         = {Supersedes v15. Density-first pipeline with
                  blind validation (19/19, 0 false positives).}
}
```
