"""
Tau-Yuan-Dupke Pipeline v16 — Null-Calibrated Prototype
========================================================
Author: Ernest C. Gatlin III
Purpose: Replace the v15 D/B threshold with a statistically
         grounded detection metric based on null-distribution
         comparison.

Key changes from v15:
  1. REMOVED Yuan 2n-3m filter (compressed spatial scale, inflated ratios)
  2. REMOVED planar slice + core excision (carved annulus = guaranteed H1)
  3. ADDED null-distribution calibration (Monte Carlo noise baseline)
  4. NEW METRIC: persistence gap = ratio of strongest H1 persistence to
     the second-strongest, measured against a null distribution
  5. ADDED sigma-based detection threshold (signal must exceed 5σ above
     the null mean for strongest H1 persistence)

Usage:
    python pipeline_v16.py                    # run with planted signal
    python pipeline_v16.py --null-only        # characterize null distribution only
    python pipeline_v16.py --blind-test       # full blind validation suite

Requirements:
    numpy, scipy, gudhi, matplotlib
"""

import numpy as np
import gudhi as gd
import matplotlib.pyplot as plt
import argparse
import json
from datetime import datetime


# ============================================================
# 1. CORE TDA — no preprocessing artifacts
# ============================================================

def compute_h1_persistence(points, max_points=5000, seed=2026):
    """
    Run GUDHI AlphaComplex on a point set and return H1 features.
    Subsamples if needed for computational feasibility.
    """
    if len(points) > max_points:
        rng = np.random.default_rng(seed)
        idx = rng.choice(len(points), max_points, replace=False)
        points = points[idx]

    if len(points) < 10:
        return []

    ac = gd.AlphaComplex(points=points)
    st = ac.create_simplex_tree()
    persistence = st.persistence(homology_coeff_field=2, min_persistence=0.0001)

    h1 = []
    for dim, (birth, death) in persistence:
        if dim == 1 and death != float('inf'):
            h1.append({
                "birth": float(birth),
                "death": float(death),
                "persistence": float(death - birth)
            })

    h1.sort(key=lambda x: x["persistence"], reverse=True)
    return h1


def extract_detection_metrics(h1_features):
    """
    Extract the metrics that matter for detection:
      - max_persistence: persistence of the strongest H1 feature
      - persistence_gap: ratio of strongest to second-strongest
      - n_significant: number of features with persistence > median
    """
    if len(h1_features) == 0:
        return {"max_persistence": 0, "persistence_gap": 0,
                "second_persistence": 0, "n_features": 0}

    p1 = h1_features[0]["persistence"]
    p2 = h1_features[1]["persistence"] if len(h1_features) > 1 else 0
    gap = p1 / p2 if p2 > 0 else float('inf')

    return {
        "max_persistence": p1,
        "second_persistence": p2,
        "persistence_gap": gap,
        "n_features": len(h1_features),
        "top_birth": h1_features[0]["birth"],
        "top_death": h1_features[0]["death"]
    }


# ============================================================
# 2. NULL DISTRIBUTION (Monte Carlo calibration)
# ============================================================

def generate_null_cloud(n_points=15000, box_size=20, seed=None):
    """Generate a uniform random point cloud (null hypothesis)."""
    rng = np.random.default_rng(seed)
    return (rng.random((n_points, 3)) - 0.5) * box_size


def build_null_distribution(n_realizations=100, n_points=15000,
                            max_tda_points=3000, master_seed=2026):
    """
    Run TDA on many pure-noise realizations to establish
    the null distribution of H1 persistence metrics.
    """
    rng = np.random.default_rng(master_seed)
    null_metrics = []

    print(f"Building null distribution from {n_realizations} realizations...")

    for i in range(n_realizations):
        seed = int(rng.integers(0, 10_000_000))
        pts = generate_null_cloud(n_points=n_points, seed=seed)
        h1 = compute_h1_persistence(pts, max_points=max_tda_points, seed=seed)
        metrics = extract_detection_metrics(h1)
        null_metrics.append(metrics)

        if (i + 1) % 10 == 0:
            print(f"  Completed {i + 1}/{n_realizations}")

    # Compute summary statistics
    max_pers = [m["max_persistence"] for m in null_metrics]
    gaps = [m["persistence_gap"] for m in null_metrics
            if m["persistence_gap"] != float('inf')]

    null_summary = {
        "n_realizations": n_realizations,
        "max_persistence": {
            "mean": float(np.mean(max_pers)),
            "std": float(np.std(max_pers)),
            "median": float(np.median(max_pers)),
            "p95": float(np.percentile(max_pers, 95)),
            "p99": float(np.percentile(max_pers, 99)),
            "max": float(np.max(max_pers)),
            "values": [float(v) for v in max_pers]
        },
        "persistence_gap": {
            "mean": float(np.mean(gaps)) if gaps else 0,
            "std": float(np.std(gaps)) if gaps else 0,
            "median": float(np.median(gaps)) if gaps else 0,
            "p95": float(np.percentile(gaps, 95)) if gaps else 0,
            "p99": float(np.percentile(gaps, 99)) if gaps else 0,
            "values": [float(v) for v in gaps]
        }
    }

    return null_summary, null_metrics


# ============================================================
# 3. SIGNAL INJECTION & DETECTION TEST
# ============================================================

def inject_shell(bg_points, radius, n_shell=4000, seed=None):
    """Inject a spherical shell at a given radius."""
    rng = np.random.default_rng(seed)
    theta = rng.uniform(0, 2 * np.pi, n_shell)
    phi = rng.uniform(0, np.pi, n_shell)
    x = radius * np.sin(phi) * np.cos(theta)
    y = radius * np.sin(phi) * np.sin(theta)
    z = radius * np.cos(phi)
    shell = np.stack([x, y, z], axis=1)
    return np.vstack([bg_points, shell])


def test_detection(points, null_summary, max_tda_points=3000, label=""):
    """
    Run TDA on a point set and compare against the null distribution.
    Returns detection verdict with sigma values.
    """
    h1 = compute_h1_persistence(points, max_points=max_tda_points)
    metrics = extract_detection_metrics(h1)

    # Compute sigma deviations from null
    null_pers = null_summary["max_persistence"]
    null_gap = null_summary["persistence_gap"]

    pers_sigma = ((metrics["max_persistence"] - null_pers["mean"])
                  / null_pers["std"]) if null_pers["std"] > 0 else 0

    gap_sigma = ((metrics["persistence_gap"] - null_gap["mean"])
                 / null_gap["std"]) if null_gap["std"] > 0 else 0

    # Detection requires BOTH metrics to be significant
    detected = (pers_sigma > 5.0) and (metrics["persistence_gap"] > null_gap["p99"])

    result = {
        "label": label,
        "metrics": metrics,
        "pers_sigma": round(float(pers_sigma), 2),
        "gap_sigma": round(float(gap_sigma), 2),
        "null_pers_mean": round(null_pers["mean"], 6),
        "null_pers_std": round(null_pers["std"], 6),
        "null_gap_p99": round(null_gap["p99"], 4),
        "detected": detected,
        "verdict": "DETECTION" if detected else "consistent with noise"
    }

    return result


# ============================================================
# 4. BLIND VALIDATION SUITE
# ============================================================

def run_blind_validation(null_summary):
    """
    Run a blind suite similar to v15 but using v16 detection logic.
    """
    rng = np.random.default_rng(7777)
    trials = []

    # 10 null trials
    for i in range(10):
        seed = int(rng.integers(0, 10_000_000))
        pts = generate_null_cloud(n_points=15000, seed=seed)
        truth = {"type": "null", "radius": None, "n_shell": 0}
        trials.append((pts, truth, f"null_{i}"))

    # 4 signal at 1.054
    for i in range(4):
        seed_bg = int(rng.integers(0, 10_000_000))
        seed_sh = int(rng.integers(0, 10_000_000))
        pts = generate_null_cloud(n_points=15000, seed=seed_bg)
        pts = inject_shell(pts, radius=1.054, n_shell=4000, seed=seed_sh)
        truth = {"type": "signal", "radius": 1.054, "n_shell": 4000}
        trials.append((pts, truth, f"signal_1054_{i}"))

    # 4 signal at other radii
    for r in [0.5, 1.5, 3.0, 5.0]:
        seed_bg = int(rng.integers(0, 10_000_000))
        seed_sh = int(rng.integers(0, 10_000_000))
        pts = generate_null_cloud(n_points=15000, seed=seed_bg)
        pts = inject_shell(pts, radius=r, n_shell=4000, seed=seed_sh)
        truth = {"type": "signal", "radius": r, "n_shell": 4000}
        trials.append((pts, truth, f"signal_r{r}"))

    # 3 weak signals at 1.054
    for n_sh in [500, 1000, 2000]:
        seed_bg = int(rng.integers(0, 10_000_000))
        seed_sh = int(rng.integers(0, 10_000_000))
        pts = generate_null_cloud(n_points=15000, seed=seed_bg)
        pts = inject_shell(pts, radius=1.054, n_shell=n_sh, seed=seed_sh)
        truth = {"type": "weak_signal", "radius": 1.054, "n_shell": n_sh}
        trials.append((pts, truth, f"weak_1054_n{n_sh}"))

    # Shuffle
    shuffle_rng = np.random.default_rng(1234)
    indices = list(range(len(trials)))
    shuffle_rng.shuffle(indices)

    print(f"\n{'=' * 75}")
    print("BLIND VALIDATION SUITE — v16 Pipeline")
    print(f"{'=' * 75}")
    print(f"{'Trial':<22} {'Pers σ':<10} {'Gap σ':<10} {'Verdict':<20} "
          f"{'Truth':<18} {'Correct?'}")
    print("-" * 90)

    tp, fp, tn, fn = 0, 0, 0, 0

    for rank, idx in enumerate(indices):
        pts, truth, name = trials[idx]
        result = test_detection(pts, null_summary, label=name)

        is_signal = truth["type"] != "null"
        detected = result["detected"]

        if is_signal and detected:
            correct = "TP"
            tp += 1
        elif is_signal and not detected:
            correct = "FN"
            fn += 1
        elif not is_signal and detected:
            correct = "FP"
            fp += 1
        else:
            correct = "TN"
            tn += 1

        truth_str = (f"r={truth['radius']},n={truth['n_shell']}"
                     if truth['radius'] else "null")

        print(f"{name:<22} {result['pers_sigma']:<10} {result['gap_sigma']:<10} "
              f"{result['verdict']:<20} {truth_str:<18} {correct}")

    print("-" * 90)
    total = tp + fp + tn + fn
    sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
    fpr = fp / (fp + tn) if (fp + tn) > 0 else 0

    print(f"\nSUMMARY")
    print(f"  Total trials:      {total}")
    print(f"  True positives:    {tp}")
    print(f"  False positives:   {fp}")
    print(f"  True negatives:    {tn}")
    print(f"  False negatives:   {fn}")
    print(f"  Sensitivity:       {sensitivity:.1%}")
    print(f"  Specificity:       {specificity:.1%}")
    print(f"  False positive rate: {fpr:.1%}")

    return {
        "tp": tp, "fp": fp, "tn": tn, "fn": fn,
        "sensitivity": sensitivity, "specificity": specificity, "fpr": fpr
    }


# ============================================================
# 5. VISUALIZATION
# ============================================================

def plot_null_vs_signal(null_summary, signal_result, save_path=None):
    """Plot the null distribution with the signal marked."""
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # Left: Max persistence distribution
    ax = axes[0]
    null_vals = null_summary["max_persistence"]["values"]
    ax.hist(null_vals, bins=30, color="steelblue", alpha=0.7,
            edgecolor="navy", label="Null distribution")
    sig_pers = signal_result["metrics"]["max_persistence"]
    ax.axvline(sig_pers, color="red", linewidth=2, linestyle="--",
               label=f"Signal ({signal_result['pers_sigma']}σ)")
    ax.axvline(null_summary["max_persistence"]["mean"], color="gray",
               linestyle=":", label="Null mean")
    ax.set_xlabel("Max H1 Persistence", fontsize=11)
    ax.set_ylabel("Count", fontsize=11)
    ax.set_title("Max H1 Persistence: Null vs Signal", fontsize=12)
    ax.legend()

    # Right: Persistence gap distribution
    ax = axes[1]
    null_gaps = null_summary["persistence_gap"]["values"]
    ax.hist(null_gaps, bins=30, color="steelblue", alpha=0.7,
            edgecolor="navy", label="Null distribution")
    sig_gap = signal_result["metrics"]["persistence_gap"]
    if sig_gap < 100:  # only plot if it fits on the axis
        ax.axvline(sig_gap, color="red", linewidth=2, linestyle="--",
                   label=f"Signal ({signal_result['gap_sigma']}σ)")
    ax.axvline(null_summary["persistence_gap"]["p99"], color="orange",
               linestyle=":", label="99th percentile")
    ax.set_xlabel("Persistence Gap (P1/P2 ratio)", fontsize=11)
    ax.set_ylabel("Count", fontsize=11)
    ax.set_title("Persistence Gap: Null vs Signal", fontsize=12)
    ax.legend()

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"Plot saved to {save_path}")
    plt.show()


# ============================================================
# 6. MAIN
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="Tau-Yuan-Dupke Pipeline v16 — Null-Calibrated"
    )
    parser.add_argument("--null-only", action="store_true",
                        help="Only build and save null distribution")
    parser.add_argument("--blind-test", action="store_true",
                        help="Run full blind validation suite")
    parser.add_argument("--n-null", type=int, default=100,
                        help="Number of null realizations (default: 100)")
    parser.add_argument("--max-tda-pts", type=int, default=3000,
                        help="Max points for GUDHI (default: 3000)")
    args = parser.parse_args()

    print("=" * 65)
    print("TAU-YUAN-DUPKE PIPELINE v16 — Null-Calibrated")
    print(f"Timestamp: {datetime.now().isoformat()}")
    print("=" * 65)

    # Step 1: Build null distribution
    print("\n--- PHASE 1: NULL DISTRIBUTION ---")
    null_summary, null_metrics = build_null_distribution(
        n_realizations=args.n_null,
        max_tda_points=args.max_tda_pts
    )

    print(f"\nNull H1 max persistence:")
    print(f"  Mean:   {null_summary['max_persistence']['mean']:.6f}")
    print(f"  Std:    {null_summary['max_persistence']['std']:.6f}")
    print(f"  95th %: {null_summary['max_persistence']['p95']:.6f}")
    print(f"  99th %: {null_summary['max_persistence']['p99']:.6f}")
    print(f"\nNull persistence gap (P1/P2):")
    print(f"  Mean:   {null_summary['persistence_gap']['mean']:.4f}")
    print(f"  Std:    {null_summary['persistence_gap']['std']:.4f}")
    print(f"  99th %: {null_summary['persistence_gap']['p99']:.4f}")

    # Save null distribution
    with open("v16_null_distribution.json", "w") as f:
        json.dump(null_summary, f, indent=2)
    print("\nNull distribution saved to v16_null_distribution.json")

    if args.null_only:
        return

    # Step 2: Test with planted signal
    print("\n--- PHASE 2: SIGNAL TEST ---")
    np.random.seed(1054)
    bg = generate_null_cloud(n_points=15000, seed=1054)
    signal_pts = inject_shell(bg, radius=1.054, n_shell=4000, seed=2026)

    signal_result = test_detection(
        signal_pts, null_summary,
        max_tda_points=args.max_tda_pts,
        label="Shell at r=1.054, n=4000"
    )

    print(f"\n  Signal max persistence: {signal_result['metrics']['max_persistence']:.6f}")
    print(f"  Signal persistence gap: {signal_result['metrics']['persistence_gap']:.4f}")
    print(f"  Sigma (persistence):    {signal_result['pers_sigma']}")
    print(f"  Sigma (gap):            {signal_result['gap_sigma']}")
    print(f"  Verdict:                {signal_result['verdict']}")

    # Step 3: Test with pure noise (sanity check)
    print("\n--- PHASE 3: NOISE SANITY CHECK ---")
    noise_pts = generate_null_cloud(n_points=15000, seed=9999)
    noise_result = test_detection(
        noise_pts, null_summary,
        max_tda_points=args.max_tda_pts,
        label="Pure noise"
    )

    print(f"\n  Noise max persistence:  {noise_result['metrics']['max_persistence']:.6f}")
    print(f"  Noise persistence gap:  {noise_result['metrics']['persistence_gap']:.4f}")
    print(f"  Sigma (persistence):    {noise_result['pers_sigma']}")
    print(f"  Sigma (gap):            {noise_result['gap_sigma']}")
    print(f"  Verdict:                {noise_result['verdict']}")

    # Step 4: Visualization
    print("\n--- PHASE 4: VISUALIZATION ---")
    try:
        plot_null_vs_signal(null_summary, signal_result,
                            save_path="v16_null_vs_signal.png")
    except Exception as e:
        print(f"  Plot skipped ({e})")

    # Step 5: Blind validation (if requested)
    if args.blind_test:
        print("\n--- PHASE 5: BLIND VALIDATION ---")
        suite_result = run_blind_validation(null_summary)

        with open("v16_blind_results.json", "w") as f:
            json.dump({
                "timestamp": datetime.now().isoformat(),
                "null_summary": {
                    "mean": null_summary["max_persistence"]["mean"],
                    "std": null_summary["max_persistence"]["std"],
                    "n_realizations": null_summary["n_realizations"]
                },
                "suite_result": suite_result
            }, f, indent=2)
        print("\nBlind results saved to v16_blind_results.json")

    # Final summary
    print(f"\n{'=' * 65}")
    print("v16 ASSESSMENT")
    print(f"{'=' * 65}")
    print(f"  Can v16 distinguish signal from noise?")
    if signal_result["detected"] and not noise_result["detected"]:
        print(f"  YES — signal detected at {signal_result['pers_sigma']}σ, "
              f"noise consistent with null")
    elif signal_result["detected"] and noise_result["detected"]:
        print(f"  NO — both signal and noise trigger detection (same as v15 problem)")
    elif not signal_result["detected"] and not noise_result["detected"]:
        print(f"  INCONCLUSIVE — neither detected; signal may be too weak for "
              f"this point density, or subsampling washes it out")
        print(f"  Try: --max-tda-pts 5000 or --n-null 200")
    else:
        print(f"  BROKEN — noise detected but signal not (pipeline inverted)")


if __name__ == "__main__":
    main()
