"""
Tav Harmonic Sweep — v19 Architecture
======================================
Author: Ernest C. Gatlin III
Date:   March 2026

Tests whether the v19 radial density scan detects planted shells
at the predicted Tav harmonic radii (multiples of 1/7 of the
base constant 7 h⁻¹ Mpc, normalized to 1.054).

Harmonics tested:
  Mode    Fraction    Normalized radius
  1/7     0.1429      ~0.151
  2/7     0.2857      ~0.301
  3/7     0.4286      ~0.452
  4/7     0.5714      ~0.602
  5/7     0.7143      ~0.753
  6/7     0.8571      ~0.903
  7/7     1.0000      ~1.054 (fundamental)
  8/7     1.1429      ~1.205
  9/7     1.2857      ~1.355
  10/7    1.4286      ~1.506

For each harmonic, the script:
  1. Plants a shell at that radius in a uniform background
  2. Runs the v19 radial density scan
  3. Records whether the peak is detected and at what significance

This establishes the pipeline's sensitivity across the full
harmonic spectrum, which the pre-analysis plan can reference
when specifying what to look for in real data.

Usage:
    python3 harmonic_sweep.py
    python3 harmonic_sweep.py --n-shell 2000    # weaker signal
    python3 harmonic_sweep.py --no-inject        # null check at all harmonics

Requirements: numpy, gudhi (for TDA confirmation), matplotlib
"""

import numpy as np
import matplotlib.pyplot as plt
import argparse
import json
from datetime import datetime

# Import v19 components (or redefine if running standalone)
try:
    from Rubin_LSST_Pipeline_v19 import (
        generate_uniform_background, inject_shell,
        radial_density_scan, find_peaks, run_detection
    )
    IMPORT_OK = True
except ImportError:
    IMPORT_OK = False


# ============================================================
# Standalone versions (in case import fails)
# ============================================================

if not IMPORT_OK:
    def generate_uniform_background(n_points=15000, box_size=20, seed=None):
        rng = np.random.default_rng(seed)
        return (rng.random((n_points, 3)) - 0.5) * box_size

    def inject_shell(bg_points, radius, n_shell=4000, seed=None):
        rng = np.random.default_rng(seed)
        theta = rng.uniform(0, 2 * np.pi, n_shell)
        phi = rng.uniform(0, np.pi, n_shell)
        x = radius * np.sin(phi) * np.cos(theta)
        y = radius * np.sin(phi) * np.sin(theta)
        z = radius * np.cos(phi)
        shell = np.stack([x, y, z], axis=1)
        return np.vstack([bg_points, shell])

    def expected_count_uniform_cube(r_low, r_high, n_total, box_half=10.0):
        vol_shell = (4.0 / 3.0) * np.pi * (r_high**3 - r_low**3)
        vol_cube = (2 * box_half) ** 3
        return n_total * (vol_shell / vol_cube)

    def radial_density_scan(points, r_min=0.3, r_max=5.0, n_bins=50,
                            n_bg=15000, box_half=10.0):
        radii = np.linalg.norm(points, axis=1)
        bin_edges = np.linspace(r_min, r_max, n_bins + 1)
        bins = []
        for i in range(n_bins):
            r_lo, r_hi = bin_edges[i], bin_edges[i + 1]
            observed = int(np.sum((radii >= r_lo) & (radii < r_hi)))
            expected = expected_count_uniform_cube(r_lo, r_hi, n_bg, box_half)
            poisson_std = np.sqrt(expected) if expected > 0 else 1
            sigma = (observed - expected) / poisson_std if poisson_std > 0 else 0
            bins.append({
                "r_low": round(float(r_lo), 4),
                "r_high": round(float(r_hi), 4),
                "r_mid": round(float((r_lo + r_hi) / 2), 4),
                "observed": observed,
                "expected": round(float(expected), 1),
                "sigma": round(float(sigma), 2)
            })
        return bins

    def find_peaks(bins, sigma_threshold=5.0):
        peaks = [b for b in bins if b["sigma"] > sigma_threshold]
        if not peaks:
            return []
        clusters = []
        current = [peaks[0]]
        for i in range(1, len(peaks)):
            if abs(peaks[i]["r_mid"] - current[-1]["r_mid"]) < \
               2 * (peaks[0]["r_high"] - peaks[0]["r_low"]):
                current.append(peaks[i])
            else:
                clusters.append(current)
                current = [peaks[i]]
        clusters.append(current)
        results = []
        for cluster in clusters:
            sigmas = [b["sigma"] for b in cluster]
            results.append({
                "peak_radius": round(float(
                    cluster[np.argmax(sigmas)]["r_mid"]), 4),
                "peak_sigma": round(float(max(sigmas)), 2),
                "total_excess": sum(b["observed"] - b["expected"]
                                    for b in cluster),
                "n_bins": len(cluster)
            })
        return results


# ============================================================
# HARMONIC DEFINITIONS
# ============================================================

BASE_CONSTANT = 1.054  # normalized Berard Constant

def get_harmonics(n_modes=10):
    """
    Generate the Tav harmonic series.
    Each mode k has normalized radius = (k/7) * BASE_CONSTANT.
    """
    harmonics = []
    for k in range(1, n_modes + 1):
        fraction = k / 7.0
        radius = fraction * BASE_CONSTANT
        harmonics.append({
            "mode": k,
            "fraction": f"{k}/7",
            "normalized_radius": round(radius, 4),
            "physical_scale_hMpc": round(radius * (7.0 / BASE_CONSTANT), 2)
        })
    return harmonics


# ============================================================
# SWEEP
# ============================================================

def run_harmonic_sweep(n_shell=4000, n_bg=15000, no_inject=False,
                       master_seed=1054):
    """
    For each harmonic, inject a shell (or not), run radial density scan,
    and record detection.
    """
    rng = np.random.default_rng(master_seed)
    harmonics = get_harmonics(n_modes=10)

    print("=" * 70)
    print("  TAV HARMONIC SWEEP — v19 Architecture")
    print(f"  {datetime.now().isoformat()}")
    print(f"  Mode: {'NULL CHECK (no injection)' if no_inject else f'Shell injection (n={n_shell})'}")
    print("=" * 70)

    print(f"\n  {'Mode':<8} {'Frac':<8} {'Radius':<10} {'~h⁻¹Mpc':<10} "
          f"{'Det?':<8} {'Peak σ':<10} {'Peak r':<10} {'Excess'}")
    print("  " + "─" * 68)

    results = []

    for h in harmonics:
        seed_bg = int(rng.integers(0, 10_000_000))
        seed_sh = int(rng.integers(0, 10_000_000))

        # Generate point cloud
        bg = generate_uniform_background(n_points=n_bg, seed=seed_bg)

        if no_inject:
            pts = bg
        else:
            pts = inject_shell(bg, radius=h["normalized_radius"],
                               n_shell=n_shell, seed=seed_sh)

        # Run radial density scan with appropriate range
        r_target = h["normalized_radius"]
        scan_min = max(0.1, r_target - 1.5)
        scan_max = min(8.0, r_target + 1.5)

        bins = radial_density_scan(pts, r_min=scan_min, r_max=scan_max,
                                   n_bins=40, n_bg=n_bg)
        peaks = find_peaks(bins, sigma_threshold=5.0)

        # Check if any peak is near the target radius
        detected = False
        best_sigma = 0
        best_radius = 0
        best_excess = 0

        if peaks:
            # Find the peak closest to our target
            for p in peaks:
                if abs(p["peak_radius"] - r_target) < 0.3:
                    if p["peak_sigma"] > best_sigma:
                        detected = True
                        best_sigma = p["peak_sigma"]
                        best_radius = p["peak_radius"]
                        best_excess = p["total_excess"]

            # If no peak near target, report the strongest anyway
            if not detected and not no_inject:
                strongest = max(peaks, key=lambda p: p["peak_sigma"])
                best_sigma = strongest["peak_sigma"]
                best_radius = strongest["peak_radius"]
                best_excess = strongest["total_excess"]
                # Check if it's reasonably close
                if abs(best_radius - r_target) < 0.5:
                    detected = True

        result = {
            "mode": h["mode"],
            "fraction": h["fraction"],
            "target_radius": h["normalized_radius"],
            "physical_scale": h["physical_scale_hMpc"],
            "detected": bool(detected),
            "peak_sigma": float(best_sigma),
            "peak_radius": float(best_radius),
            "excess_points": float(best_excess),
            "injected": not no_inject
        }
        results.append(result)

        det_str = "YES" if detected else "no"
        print(f"  {h['mode']:<8} {h['fraction']:<8} {h['normalized_radius']:<10} "
              f"{h['physical_scale_hMpc']:<10} "
              f"{det_str:<8} {best_sigma:<10.1f} {best_radius:<10.4f} "
              f"{best_excess:.0f}")

    # Summary
    n_detected = sum(1 for r in results if r["detected"])
    print(f"\n  {'─' * 68}")
    print(f"  Detected: {n_detected}/{len(results)} harmonics")

    if no_inject:
        print(f"  (All should be 'no' — this is the null check)")
        n_false = sum(1 for r in results if r["detected"])
        if n_false == 0:
            print(f"  ★ CLEAN: Zero false detections across all harmonics")
        else:
            print(f"  ✗ WARNING: {n_false} false detections in null data")
    else:
        print(f"  (All should be 'YES' if pipeline has sufficient sensitivity)")
        n_missed = sum(1 for r in results if not r["detected"])
        if n_missed > 0:
            missed = [r for r in results if not r["detected"]]
            print(f"  Note: {n_missed} harmonics below detection threshold:")
            for m in missed:
                print(f"    Mode {m['mode']}: r={m['target_radius']} "
                      f"(may be outside scan range or too few points in bin)")

    return results


# ============================================================
# VISUALIZATION
# ============================================================

def plot_harmonic_sweep(results, save_path=None):
    """Bar chart of detection significance across harmonics."""
    fig, axes = plt.subplots(2, 1, figsize=(14, 8), gridspec_kw={"height_ratios": [3, 1]})

    modes = [r["mode"] for r in results]
    radii = [r["target_radius"] for r in results]
    sigmas = [r["peak_sigma"] for r in results]
    detected = [r["detected"] for r in results]

    # Top panel: significance
    ax = axes[0]
    colors = ["#c0392b" if d else "#bdc3c7" for d in detected]
    bars = ax.bar(modes, sigmas, color=colors, edgecolor="navy",
                  alpha=0.8, linewidth=0.5)
    ax.axhline(5.0, color="red", linestyle=":", linewidth=1,
               label="5σ threshold", alpha=0.7)
    ax.set_ylabel("Peak Significance (σ)", fontsize=12)
    ax.set_title("Tav Harmonic Sweep: Detection Significance by Mode",
                 fontsize=13, fontweight="bold")
    ax.legend(fontsize=10)
    ax.set_xticks(modes)
    ax.set_xticklabels([f"k={m}\nr={radii[i]:.2f}" for i, m in enumerate(modes)],
                       fontsize=8)

    # Bottom panel: target vs detected radius
    ax2 = axes[1]
    det_radii = [r["peak_radius"] if r["detected"] else 0 for r in results]
    ax2.scatter(modes, radii, color="navy", s=80, zorder=3, label="Target radius")
    for i, m in enumerate(modes):
        if detected[i]:
            ax2.scatter(m, det_radii[i], color="red", s=40, marker="x",
                        zorder=4, linewidths=2)
    ax2.set_xlabel("Harmonic Mode (k)", fontsize=12)
    ax2.set_ylabel("Radius", fontsize=12)
    ax2.set_xticks(modes)
    ax2.legend(fontsize=10)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"\n  Plot saved to {save_path}")
    plt.show()

    return fig


# ============================================================
# MAIN
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="Tav Harmonic Sweep — v19 Architecture"
    )
    parser.add_argument("--n-shell", type=int, default=4000,
                        help="Shell points per harmonic (default: 4000)")
    parser.add_argument("--no-inject", action="store_true",
                        help="Null check: scan without injecting any signal")
    parser.add_argument("--no-plot", action="store_true",
                        help="Skip visualization")
    args = parser.parse_args()

    results = run_harmonic_sweep(
        n_shell=args.n_shell,
        no_inject=args.no_inject
    )

    # Save results
    output = {
        "timestamp": datetime.now().isoformat(),
        "pipeline": "v19",
        "mode": "null_check" if args.no_inject else f"injection_n{args.n_shell}",
        "harmonics": results
    }
    outfile = "harmonic_sweep_results.json"
    with open(outfile, "w") as f:
        json.dump(output, f, indent=2)
    print(f"\n  Results saved to {outfile}")

    if not args.no_plot:
        try:
            plot_harmonic_sweep(results,
                                save_path="harmonic_sweep.png")
        except Exception as e:
            print(f"\n  Plot skipped: {e}")

    # Suggest null check if not already done
    if not args.no_inject:
        print(f"\n  Next: run the null check to verify zero false positives:")
        print(f"    python3 harmonic_sweep.py --no-inject")


if __name__ == "__main__":
    main()
