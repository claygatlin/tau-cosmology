import os
from PIL import Image

# 1. Define the directory where your 17 versions are saved
image_folder = '/home/ernest-gatlin/Desktop/Rubin_LSST Point Cloud Analysis/'
output_gif = os.path.join(image_folder, 'Tau_Universe_Cosmic_Evolution.gif')

# 2. Collect all versioned PNGs and sort them numerically
# This assumes files are named like 'Tav_Vortex_Analysis_v1.png', etc.
images = []
file_list = sorted([f for f in os.listdir(image_folder) if f.endswith('.png')], 
                   key=lambda x: int(''.join(filter(str.isdigit, x)) or 0))

print(f"Stitching {len(file_list)} versions of the Tav Topology...")

for filename in file_list:
    img_path = os.path.join(image_folder, filename)
    img = Image.open(img_path)
    # Ensure all frames are the same size for a smooth transition
    img = img.convert('RGB')
    images.append(img)

# 3. Save as an animated GIF
if images:
    images[0].save(
        output_gif,
        save_all=True,
        append_images=images[1:],
        duration=800, # 0.8 seconds per 'evolutionary' step
        loop=0        # Infinite loop
    )
    print(f"Success! The Cosmic Evolution GIF is ready at: {output_gif}")
else:
    print("Error: No PNG files found. Ensure you saved your v1-v17 plots first!")
