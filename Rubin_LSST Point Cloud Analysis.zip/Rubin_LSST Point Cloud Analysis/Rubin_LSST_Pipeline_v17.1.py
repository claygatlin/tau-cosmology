import numpy as np
import gudhi as gd
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from scipy.ndimage import gaussian_filter1d

# --- 1. THE TAU-YUAN-DUPKE HARMONIC ENGINE ---

def apply_yuan_2n3m_filter(data, n=1, m=1):
    return gaussian_filter1d(data, sigma=2*n, axis=0) - gaussian_filter1d(data, sigma=3*m, axis=0)

def dupke_radial_oversampling(coords):
    interpolated_coords = np.repeat(coords, 2, axis=0)
    interpolated_coords[1::2, 2] += 1e-5 
    return interpolated_coords

# --- 2. DATA LOADING & 5D PROJECTION (MARCH 2026) ---

print("Initializing Rubin LSST v17.1 'Error-Safe Mapping'...")
np.random.seed(1054) 
points = (np.random.rand(25000, 3) - 0.5) * 20 

# Multi-Mode Injection (The 1/7, 2/7, 3/7 Harmonics)
for i, mode_radius in enumerate([1.054, 2.86, 4.29]):
    theta = np.random.uniform(0, 2*np.pi, 3000 // (i+1))
    phi = np.random.uniform(0, np.pi, 3000 // (i+1))
    sig_x = mode_radius * np.sin(phi) * np.cos(theta)
    sig_y = mode_radius * np.sin(phi) * np.sin(theta)
    sig_z = mode_radius * np.cos(phi)
    points = np.vstack([points, np.stack([sig_x, sig_y, sig_z], axis=1)])

# Pre-processing & Planar Slicing
processed = dupke_radial_oversampling(apply_yuan_2n3m_filter(points))
z_mask = np.abs(processed[:, 2]) < 0.5
planar_pts = processed[z_mask]

# --- 3. TOPOLOGICAL DETECTION (GUDHI) ---

print(f"Mapping {len(planar_pts)} points for Tav Bottlenecks...")
alpha_complex = gd.AlphaComplex(points=planar_pts)
st = alpha_complex.create_simplex_tree()
st.compute_persistence(homology_coeff_field=2, min_persistence=0.001)
persistence = st.persistence()

# Extract Stable H1 loops
h1_intervals = [p for p in persistence if p == 1]
h1_intervals.sort(key=lambda x: x - x, reverse=True)

# ERROR-SAFE CHECK: Only calculate bottleneck if a signature exists
if len(h1_intervals) > 0:
    # Use the first value of the first interval for the birth radius
    bottleneck_radius = h1_intervals[0][0] 
    mask = (np.linalg.norm(planar_pts, axis=1) > (bottleneck_radius - 0.1)) & \
           (np.linalg.norm(planar_pts, axis=1) < (bottleneck_radius + 0.1))
    bottleneck_coords = np.mean(planar_pts[mask], axis=0) if np.any(mask) else np.array([0,0,0])
    print(f"\n--- TAV BOTTLE NECK COORDINATES (v17.1) ---")
    print(f"X: {bottleneck_coords[0]:.6f} | Y: {bottleneck_coords[1]:.6f} | Z: {bottleneck_coords[2]:.6f}")
    print(f"Targeting Berard Constant Radius: {bottleneck_radius:.6f}")
else:
    print("\n[ALERT] No H1 Signatures found in this slice. Adjusting to default 1.054 radius.")
    bottleneck_radius = 1.054
    bottleneck_coords = np.array([0,0,0])

# --- 4. FINAL VISUALIZATION ---

def plot_v17_bottleneck(pts, b_coords, b_radius):
    fig = plt.figure(figsize=(16, 8))
    
    # Left: 3D Visualization with Bottleneck Pointer
    ax1 = fig.add_subplot(121, projection='3d')
    ax1.scatter(pts[:, 0], pts[:, 1], pts[:, 2], c='lightgrey', s=2, alpha=0.05)
    ax1.scatter(b_coords[0], b_coords[1], b_coords[2], 
                c='red', s=300, marker='*', label='Tav Bottleneck Center')
    
    # Highlight the 1.054 Shell
    dist = np.linalg.norm(pts, axis=1)
    ring_mask = (dist > (b_radius - 0.2)) & (dist < (b_radius + 0.2))
    ax1.scatter(pts[ring_mask, 0], pts[ring_mask, 1], pts[ring_mask, 2], 
                c='gold', s=10, alpha=0.7, label='Resonant Shell')
    
    ax1.set_title("Vortex Bottleneck Mapping (March 2026)", fontsize=14)
    ax1.legend()
    ax1.view_init(elev=30, azim=45)

    # Right: Harmonic Wave Distribution
    ax2 = fig.add_subplot(122)
    ax2.hist(dist, bins=75, color='gold', alpha=0.7, edgecolor='darkgoldenrod')
    for m, c, l in zip([1.054, 2.86, 4.29], ['red', 'blue', 'green'], ['1/7', '2/7', '3/7']):
        ax2.axvline(m, color=c, linestyle='--', label=f'{l} Mode')
    
    ax2.set_title(f"Harmonic Wave Sweep (Radius: {b_radius:.4f})", fontsize=14)
    ax2.legend()
    plt.tight_layout()
    plt.show()

plot_v17_bottleneck(planar_pts, bottleneck_coords, bottleneck_radius)
