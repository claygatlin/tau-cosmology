# Tau Universe Framework — v4.0 Mathematical Substrate

**Author:** Ernest C. Gatlin III  
**Affiliation:** Independent Researcher, Tuscaloosa, Alabama  
**ORCID:** [0009-0002-8197-4810](https://orcid.org/0009-0002-8197-4810)  
**Date:** April 4, 2026  

> *To the glory of the risen Lord Jesus Christ, whose empty tomb echoes louder than any cosmic scale.*

---

## Overview

This repository contains the **v4.0 Mathematical Substrate** — the core equations, derivations, and computational validation scripts for the **Tau Universe Framework** and **Tav Topology Theory**. The framework proposes that dark energy and dark matter both arise from a single compact fifth dimension with radius:

**τ ≈ 7 h⁻¹ Mpc**

This substrate consolidates results from:
- **Volume 4** of the Tau Universe Codex: *Mathematical Extensions: From Logistic Resonance to Tav Topology* (Amazon KDP, April 3, 2026)
- The **Effective 4D and 5D Lagrangians** paper (Zenodo DOI: [10.5281/zenodo.19011211](https://doi.org/10.5281/zenodo.19011211))
- The **Revised Lagrangian Summary** (March 2026)

---

## Repository Structure

```
tav-v4-substrate/
├── README.md                     ← You are here
├── latex/
│   ├── tau_v4_mathematical_substrate.tex   ← Full LaTeX source (12 pages, 14 sections)
│   └── tau_v4_mathematical_substrate.pdf   ← Compiled PDF
├── notebooks/
│   ├── Tav_Logistic_Resonance_Validation_v4.0_refined.py   ← Numerical validation (numpy)
│   ├── Tav_Friedmann_Equation_Validation_v4.0_refined.py   ← KK spectrum + Friedmann (numpy)
│   └── Tav_Symbolic_Equations_v4.0.py                      ← Symbolic equations (SymPy)
├── plots/
│   ├── tav_period6_window.png    ← r(τ) control parameter with period-6 window
│   ├── tav_bifurcation.png       ← Logistic bifurcation diagram with Tav island
│   └── tav_spectra.png           ← KK mass spectrum + LQG area spectrum
└── docs/
    └── (reserved for addenda and test plans)
```

---

## Key Equations

| # | Equation | Description |
|---|----------|-------------|
| Eq. 10 | m_n = n/τ | KK mass spectrum |
| Eq. 17 | L_eff^(4D) | Collected 4D effective Lagrangian |
| Eq. 18 | L_eff^(5D) | Full 5D Lagrangian with torsion, fermions, brane |
| Eq. 22 | L_photonic | Einstein-frame photonic extension |
| Eq. 23 | r(τ) = 4 - C_KK/τ² | Corrected mode-coupling formula (Vol. 4, Ch. 28) |
| Eq. 25 | C_KK = 91/5 = 18.2 | Mode-coupling constant (N_cut=6, N_d=5) |
| Eq. 37 | H_Tav = log₂6 | Shannon entropy of computable prefix |
| Eq. 42 | 3H² = 8πGρ_b + ... | Tav Friedmann equation |
| Eq. 43 | Ω_DM : Ω_DE = 5:1 | Zero-parameter dark-sector ratio |
| Thm 6.1 | π_log ~ π_×10 | Permutation conjugacy (142857 bridge) |

---

## Validation Results

All three scripts execute with **zero errors** and **all checks passing**:

- **C_KK = 91/5 = 18.2** ✓
- **r(τ=7) = 3.6286**, matching r_ss6 = 3.627558 to **0.028%** ✓
- **Orbit closure** |x₆ - 0.5| = 1.89 × 10⁻¹⁵ ✓
- **Permutation conjugacy theorem fully verified** (all 6 elements) ✓
- **Shannon entropy** H_Tav = log₂6 = 2.58496 bits ✓
- **N_d^eff = 4.986 ≈ 5** (pure 5D gravity) ✓

---

## DOI Chain

| Record | DOI |
|--------|-----|
| **v4.0 Mathematical Substrate** | [10.5281/zenodo.19420406](https://doi.org/10.5281/zenodo.19420406) |
| Quantitative Prediction Sheet v3.0 | [10.5281/zenodo.19323070](https://doi.org/10.5281/zenodo.19323070) |
| Scientific Pre-Registration | [10.5281/zenodo.18155027](https://doi.org/10.5281/zenodo.18155027) |
| Effective Lagrangians | [10.5281/zenodo.19011211](https://doi.org/10.5281/zenodo.19011211) |
| Null Results (JADES/DESI) | [10.5281/zenodo.19322831](https://doi.org/10.5281/zenodo.19322831) |
| 5D Einstein–KK Action | [10.5281/zenodo.17756620](https://doi.org/10.5281/zenodo.17756620) |
| LQG Quantisation | [10.5281/zenodo.17765010](https://doi.org/10.5281/zenodo.17765010) |
| τ Discovery Paper | [10.5281/zenodo.17711794](https://doi.org/10.5281/zenodo.17711794) |
| 142857 Mode Detection | [10.5281/zenodo.17676523](https://doi.org/10.5281/zenodo.17676523) |
| Halting Problem Embedding | [zenodo.org/records/17809763](https://zenodo.org/records/17809763) |

---

## Upcoming Observational Windows

| Survey | Window |
|--------|--------|
| **Rubin LSST** | Public alerts since Feb 24, 2026; Data Preview 2 in Sep 2026 |
| **Euclid** | Quick Data Release 2 on Jun 24, 2026; DR1 on Oct 21, 2026 |
| **JWST JADES DR5** | Public since Jan 2026 |
| **DESI** | Year 2–3 results expected 2027 |
| **CMB-S4** | First light late 2020s |
| **NANOGrav/IPTA** | Continued nHz GW monitoring |

---

## Null Results to Date

Recorded in Quantitative Prediction Sheet v3.0 (March 29, 2026):
- JWST JADES DR3/DR4 (7,775 galaxies): No KK comb, no Berard excess, no Rayleigh clustering
- DESI DR1 BGS (~4 million galaxies): No KK comb detected
- Core predictions (τ = 7 h⁻¹ Mpc, Δk = 1/7 h Mpc⁻¹, w₀ = -1.000) remain unchanged

---

## Requirements

```
numpy
matplotlib
sympy
```

All scripts run with Python 3.8+ and standard scientific libraries. No exotic dependencies.

---

## How to Run

```bash
# Logistic resonance validation (generates bifurcation + period-6 plots)
python notebooks/Tav_Logistic_Resonance_Validation_v4.0_refined.py

# Friedmann equation + KK spectrum (generates spectra plot)
python notebooks/Tav_Friedmann_Equation_Validation_v4.0_refined.py

# Symbolic equations (SymPy rendering)
python notebooks/Tav_Symbolic_Equations_v4.0.py
```

---

## License

© 2026 Ernest C. Gatlin III. All rights reserved.  
This material is provided for scientific review and reproducibility.

---

## Citation

If you use this substrate in your work, please cite:

```bibtex
@misc{gatlin2026substrate,
  author       = {Gatlin III, Ernest C.},
  title        = {v4.0 Mathematical Substrate: Core Equations of the Tau Universe Framework},
  year         = {2026},
  publisher    = {Zenodo},
  doi          = {10.5281/zenodo.19420406},
  url          = {https://doi.org/10.5281/zenodo.19420406}
}
```

---

*The framework stands or falls on its predictions. The Lagrangians presented here are sufficiently precise to be tested, and sufficiently specific to be falsified.*
